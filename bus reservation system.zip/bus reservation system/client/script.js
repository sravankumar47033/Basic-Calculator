document.addEventListener('DOMContentLoaded', () => {
    const busListEl = document.getElementById('buses');
    const busSelectEl = document.getElementById('bus-select');
    const reservationForm = document.getElementById('reservation-form');
    const messageEl = document.getElementById('message');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const showLoginLink = document.getElementById('show-login');
    const showSignupLink = document.getElementById('show-signup');
    const reservationsListEl = document.getElementById('reservations');
    const viewReservationsBtn = document.getElementById('view-reservations-btn');

    const signupSection = document.getElementById('signup-section');
    const loginSection = document.getElementById('login-section');
    const reservationSection = document.getElementById('reservation-section');

    let loggedInUsername = null;

    const handleSignup = async (e) => {
        e.preventDefault();
        const username = signupForm.newUsername.value;
        const password = signupForm.newPassword.value;

        try {
            const response = await fetch('http://localhost:5000/api/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();
            if (response.ok) {
                messageEl.textContent = data.message + ' Please log in.';
                messageEl.style.color = 'green';
                signupSection.style.display = 'none';
                loginSection.style.display = 'block';
                loginForm.reset();
            } else {
                messageEl.textContent = data.message;
                messageEl.style.color = 'red';
            }
        } catch (error) {
            console.error('Error during sign-up:', error);
            messageEl.textContent = 'Failed to sign up. Server is not reachable.';
            messageEl.style.color = 'red';
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        const username = loginForm.username.value;
        const password = loginForm.password.value;

        try {
            const response = await fetch('http://localhost:5000/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();
            if (response.ok) {
                loginSection.style.display = 'none';
                reservationSection.style.display = 'block';
                messageEl.textContent = data.message;
                messageEl.style.color = 'green';
                loggedInUsername = username;
                fetchBuses();
                fetchReservations();
            } else {
                messageEl.textContent = data.message;
                messageEl.style.color = 'red';
            }
        } catch (error) {
            console.error('Error during login:', error);
            messageEl.textContent = 'Failed to log in. Server is not reachable.';
            messageEl.style.color = 'red';
        }
    };

    const fetchBuses = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/buses');
            const buses = await response.json();
            renderBuses(buses);
        } catch (error) {
            console.error('Error fetching buses:', error);
            messageEl.textContent = 'Failed to load bus data. Please try again later.';
            messageEl.style.color = 'red';
        }
    };
    
    const fetchReservations = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/reservations');
            const reservations = await response.json();
            renderReservations(reservations);
        } catch (error) {
            console.error('Error fetching reservations:', error);
        }
    };

    const renderBuses = (buses) => {
        busListEl.innerHTML = '';
        busSelectEl.innerHTML = '';
        buses.forEach(bus => {
            const availableSeats = bus.seats - bus.booked;
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <strong>Route:</strong> ${bus.route} <br>
                <strong>Available Seats:</strong> ${availableSeats} / ${bus.seats}
            `;
            if (availableSeats === 0) {
                listItem.classList.add('full');
            }
            busListEl.appendChild(listItem);

            const option = document.createElement('option');
            option.value = bus.id;
            option.textContent = `${bus.route} (${availableSeats} seats available)`;
            busSelectEl.appendChild(option);
        });
    };
    
    const deleteReservation = async (reservationId) => {
      try {
        const response = await fetch(`http://localhost:5000/api/reservations/${reservationId}`, {
          method: 'DELETE'
        });
        const data = await response.json();
        if (response.ok) {
          messageEl.textContent = data.message;
          messageEl.style.color = 'green';
          fetchBuses();
          fetchReservations();
        } else {
          messageEl.textContent = data.message;
          messageEl.style.color = 'red';
        }
      } catch (error) {
        console.error('Error cancelling reservation:', error);
        messageEl.textContent = 'Failed to cancel reservation. Server is not reachable.';
        messageEl.style.color = 'red';
      }
    };

    const renderReservations = (reservations) => {
      reservationsListEl.innerHTML = '';
      if (reservations.length === 0) {
          reservationsListEl.innerHTML = '<li>No reservations found.</li>';
          return;
      }
      reservations.forEach(res => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
          <strong>User:</strong> ${res.username}<br>
          <strong>Bus ID:</strong> ${res.busId}<br>
          <strong>Seats:</strong> ${res.seatsToBook}<br>
          <strong>Date:</strong> ${new Date(res.timestamp).toLocaleDateString()}
          <button class="cancel-btn" data-id="${res.id}">Cancel</button>
        `;
        reservationsListEl.appendChild(listItem);
      });
      
      // Add event listeners to the new cancel buttons
      document.querySelectorAll('.cancel-btn').forEach(button => {
        button.addEventListener('click', (e) => {
          const reservationId = e.target.dataset.id;
          deleteReservation(reservationId);
        });
      });
    };

    const handleReservation = async (e) => {
        e.preventDefault();
        const busId = reservationForm.busId.value;
        const seatsToBook = parseInt(reservationForm.seatsToBook.value);

        try {
            const response = await fetch('http://localhost:5000/api/reserve', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ busId, seatsToBook, username: loggedInUsername })
            });

            const data = await response.json();
            if (response.ok) {
                messageEl.textContent = data.message;
                messageEl.style.color = 'green';
                fetchBuses();
                fetchReservations();
            } else {
                messageEl.textContent = data.message;
                messageEl.style.color = 'red';
            }
        } catch (error) {
            console.error('Error making reservation:', error);
            messageEl.textContent = 'Failed to make reservation. Server is not reachable.';
            messageEl.style.color = 'red';
        }
    };

    // Add event listeners
    signupForm.addEventListener('submit', handleSignup);
    loginForm.addEventListener('submit', handleLogin);
    reservationForm.addEventListener('submit', handleReservation);
    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        signupSection.style.display = 'none';
        loginSection.style.display = 'block';
    });
    showSignupLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginSection.style.display = 'none';
        signupSection.style.display = 'block';
    });
    viewReservationsBtn.addEventListener('click', fetchReservations);
});
