// server.js
const express = require('express');
const cors = require('cors');

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

let buses = [
  { id: 1, route: "Hyderabad to Chennai", seats: 20, booked: 5 },
  { id: 2, route: "Hyderabad to Bengaluru", seats: 30, booked: 10 },
  { id: 3, route: "Hyderabad to Mumbai", seats: 25, booked: 25 },
];

let reservations = [];
let users = {};

app.post('/api/signup', (req, res) => {
    const { username, password } = req.body;
    if (users[username]) {
        return res.status(400).json({ message: "Username already exists." });
    }
    users[username] = password;
    res.status(201).json({ message: "Sign up successful." });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (users[username] === password) {
        res.status(200).json({ message: "Login successful." });
    } else {
        res.status(401).json({ message: "Invalid credentials." });
    }
});

app.get('/api/buses', (req, res) => {
  res.json(buses);
});

app.get('/api/reservations', (req, res) => {
  res.json(reservations);
});

app.post('/api/reserve', (req, res) => {
  const { busId, seatsToBook, username } = req.body;
  const bus = buses.find(b => b.id === parseInt(busId));

  if (!bus) {
    return res.status(404).json({ message: "Bus not found." });
  }

  if (bus.booked + seatsToBook > bus.seats) {
    return res.status(400).json({ message: "Not enough seats available." });
  }

  bus.booked += seatsToBook;
  const newReservation = {
    id: reservations.length + 1,
    busId,
    username,
    seatsToBook,
    timestamp: new Date().toISOString()
  };
  reservations.push(newReservation);

  res.status(200).json({ message: "Reservation successful!", bus, reservation: newReservation });
});

app.delete('/api/reservations/:id', (req, res) => {
  const reservationId = parseInt(req.params.id);
  const reservationIndex = reservations.findIndex(res => res.id === reservationId);

  if (reservationIndex === -1) {
    return res.status(404).json({ message: "Reservation not found." });
  }

  const reservation = reservations[reservationIndex];
  const bus = buses.find(b => b.id === reservation.busId);
  if (bus) {
    bus.booked -= reservation.seatsToBook;
  }

  reservations.splice(reservationIndex, 1);
  res.status(200).json({ message: "Reservation cancelled successfully." });
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
